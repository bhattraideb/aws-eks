[//]: # (https://python-poetry.org/docs/basic-usage/)
[//]: # (poetry run django-admin startproject user_management .)
[//]: # (poetry run python manage.py runserver)